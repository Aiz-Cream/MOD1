<?php
// ============================================================
// KameraPH | Module 1: User Account and Identity
// The ONLY file that holds settings. Change values here, nowhere else.
// If config.local.php exists, its values override the defaults below.
// Environment variable overrides take highest precedence.
// ============================================================

// Load defaults first
$config = [
    // ---- Database: LOCAL XAMPP (default) ----
    // 1. Start Apache + MySQL in the XAMPP Control Panel.
    // 2. In phpMyAdmin, import sql/xampp_setup.sql (it creates the database for you).
    "env"     => "local",
    "host"    => "127.0.0.1",
    "port"    => 3306,
    "dbname"  => "kph_user_account_identity",
    "user"    => "root",
    "pass"    => "",
    "charset" => "utf8mb4",
    "ssl_ca"  => "",

    // Azure MySQL (shared kph-database): put these in config/config.local.php instead,
    // never here. See config.local.example.php.

    // ---- Secrets ----
    // 64 hex characters (32 bytes). Used to encrypt ID numbers and to scramble tokens.
    // PLACEHOLDER (all zeros) for sharing. Put your own 64 hex characters here. Never change it later.
    "encryption_key" => "0000000000000000000000000000000000000000000000000000000000000000",

    // Shared secret that the other 9 modules send in the X-Module-Key header
    // so that they may read user data on the server side. Share it with the other groups.
    "module_key" => "kph-shared-module-key-change-me",

    // ---- Rules ----
    "token_minutes" => [
        "verify_email"   => 30,
        "verify_phone"   => 10,
        "reset_password" => 30,
        "session"        => 1440
    ],
    "max_addresses_per_user" => 10,

    // ---- Shipping & payment (commerce) ----
    // Shipping is calculated per seller order: free when that order's
    // subtotal >= free_threshold, otherwise flat_fee. Pickup is free.
    "shipping" => [
        "flat_fee"                => 150.00,
        "free_threshold"          => 2000.00,
        "pickup_fee"              => 0.00,
        "pickup_requires_address" => false
    ],
    "payment" => [
        // COD only; an online gateway is not available yet.
        "methods" => ["COD"]
    ],

    // While payment, email and SMS are simulated, the API returns the code/token
    // in the response of send-token. Set to false for the final demo.
    "show_token_in_response" => true,

    // ---- HARDCODED CODES (no real email/SMS yet) ----
    // While true, every verification code (email, phone, change of email/phone)
    // and every password-reset code is the fixed value below.
    // Set to false once real email/SMS sending exists.
    "use_demo_codes" => true,
    "demo_code"      => "123456",

    // ---- Other modules (base API addresses, no slash at the end) ----
    "modules" => [
        "accounts"    => "http://localhost/kph_user_account_identity/api",
        "sellers"     => "http://localhost/kph_seller_verification/api",
        "catalog"     => "http://localhost/kph_catalog_specification/api",
        "engagement"  => "http://localhost/kph_marketing_engagement/api",
        "shopping"    => "http://localhost/kph_shopping_promotions/api",
        "orders"      => "http://localhost/kph_order_payment/api",
        "fulfillment" => "http://localhost/kph_fulfillment_logistics/api",
        "shipping"    => "http://localhost/kph_shipping_delivery/api",
        "support"     => "http://localhost/kph_post_purchase_support/api",
        "admin"       => "http://localhost/kph_administration_analytics/api"
    ],

    // Module 1 works alone. Set to true only after Module 4 (notifications)
    // and Module 10 (logs) agree on the endpoints used in api/helpers.php.
    "call_other_modules" => false
];

// Private local configuration overrides
    $localConfigFile = __DIR__ . '/config.local.php';
    if (is_file($localConfigFile)) {
        $localConfig = require $localConfigFile;
        if (is_array($localConfig)) {
            $config = array_replace_recursive($config, $localConfig);
        }
    }

    // Environment variable overrides (highest priority)
    $envMap = [
        'DB_HOST'    => 'host',
        'DB_PORT'    => 'port',
        'DB_NAME'    => 'dbname',
        'DB_USER'    => 'user',
        'DB_PASS'    => 'pass',
        'DB_CHARSET' => 'charset',
        'DB_SSL_CA'  => 'ssl_ca',
        'DB_ENV'     => 'env',
    ];
    foreach ($envMap as $envVar => $configKey) {
        $value = getenv($envVar);
        if ($value !== false && $value !== '') {
            if ($configKey === 'port') {
                $config[$configKey] = (int)$value;
            } else {
                $config[$configKey] = $value;
            }
        }
    }

return $config;