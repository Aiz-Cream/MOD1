<?php
// Azure MySQL (shared kph-database). Git ignores this file - never commit or share it.
return [
    "env"     => "azure",
    "host"    => "kamaera-ph-mysql.mysql.database.azure.com",
    "port"    => 3306,
    "dbname"  => "kph-database",
    "user"    => "sqladmin",
    "pass"    => "Admin123!",
    "charset" => "utf8mb4",
    "ssl_ca"  => __DIR__ . '/ssl/DigiCertGlobalRootG2.crt.pem',
];
